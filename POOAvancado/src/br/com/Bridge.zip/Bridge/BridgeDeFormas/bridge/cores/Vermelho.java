package br.com.Bridge.BridgeDeFormas.bridge.cores;

//Implementa��o Vermelho
public class Vermelho implements Cor {
 @Override
 public void aplicarCor() {
     System.out.println("Aplicando a cor vermelha");
 }
}
