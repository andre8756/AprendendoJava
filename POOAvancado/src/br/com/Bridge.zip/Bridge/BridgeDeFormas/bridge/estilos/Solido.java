package br.com.Bridge.BridgeDeFormas.bridge.estilos;

public class Solido implements Estilo{

	@Override
	public void aplicarEstilo() {
		System.out.println("Aplicando o estilo solido");
	}

}
