package br.com.Bridge.BridgeDeFormas.bridge.estilos;

public class Tracejado implements Estilo{

	@Override
	public void aplicarEstilo() {
		System.out.println("Aplicando o estilo Tracejado");
		
	}

}
