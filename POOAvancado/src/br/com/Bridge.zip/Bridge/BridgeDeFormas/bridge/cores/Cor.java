package br.com.Bridge.BridgeDeFormas.bridge.cores;

//Interface de implementa��o
public interface Cor {
 public void aplicarCor();
}
