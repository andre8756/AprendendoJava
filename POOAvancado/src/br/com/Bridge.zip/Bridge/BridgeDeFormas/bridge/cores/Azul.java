package br.com.Bridge.BridgeDeFormas.bridge.cores;

//Implementa��o Azul
public class Azul implements Cor {
 @Override
 public void aplicarCor() {
     System.out.println("Aplicando a cor azul");
 }
}
