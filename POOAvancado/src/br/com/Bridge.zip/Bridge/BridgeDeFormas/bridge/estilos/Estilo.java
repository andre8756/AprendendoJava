package br.com.Bridge.BridgeDeFormas.bridge.estilos;

public interface Estilo {
	public void aplicarEstilo();
}
