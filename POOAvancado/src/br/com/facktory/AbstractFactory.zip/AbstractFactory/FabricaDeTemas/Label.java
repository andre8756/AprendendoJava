package br.com.facktory.AbstractFactory.FabricaDeTemas;

public interface Label {
	void paint();
}
