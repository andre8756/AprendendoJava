package br.com.facktory.AbstractFactory.FabricaDeTemas;

public interface Textbox {
	void paint();
}
