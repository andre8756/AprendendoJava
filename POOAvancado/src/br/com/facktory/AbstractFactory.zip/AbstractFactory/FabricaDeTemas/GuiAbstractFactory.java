package br.com.facktory.AbstractFactory.FabricaDeTemas;

public interface GuiAbstractFactory {
	Label createLabel();
	Textbox createTextobox();
}
