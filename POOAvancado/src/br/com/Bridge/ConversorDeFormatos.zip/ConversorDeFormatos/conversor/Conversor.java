package br.com.Bridge.ConversorDeFormatos.conversor;

public interface Conversor {
	public void converter();
	public void converter(String nome, int idade, double salario);
	
}
