package br.com.model.AbstractFactory.FabricaDeTemas;
import br.com.facktory.AbstractFactory.FabricaDeTemas.*;

public class TemaClaroLabel implements Label{

	@Override
	public void paint() {
		System.out.println("Label tema claro");
		
	}
	
}
