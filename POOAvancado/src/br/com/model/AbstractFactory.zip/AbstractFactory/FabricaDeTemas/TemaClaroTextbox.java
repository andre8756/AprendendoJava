package br.com.model.AbstractFactory.FabricaDeTemas;

import br.com.facktory.AbstractFactory.FabricaDeTemas.*;

public class TemaClaroTextbox implements Textbox {

	@Override
	public void paint() {
		System.out.println("Textbox tema claro");
		
	}

}
