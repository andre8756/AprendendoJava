package TransacaoBancaria;

public class TransacaoConcluida {
	public void concluirTransacao() {
		System.out.println("");
		System.out.println("Transacao concluida com sucesso!");
	}
}
