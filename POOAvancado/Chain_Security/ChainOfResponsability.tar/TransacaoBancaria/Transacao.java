package TransacaoBancaria;

import java.time.LocalTime;

public class Transacao {
	private double valor;
	private double saldoDisponivel;
	private double limiteCredito;
	private LocalTime horaTransacao;
	private LocalTime HorarioLimiteIncio = LocalTime.of(6, 0);
	private LocalTime horarioLimiteFim = LocalTime.of(18, 0);
	
	
	//Getters e Setters
	public double getValor() {
		return valor;
	}
	public void setValor(double valor) {
		this.valor = valor;
	}
	public double getSaldoDisponivel() {
		return saldoDisponivel;
	}
	public void setSaldoDisponivel(double saldoDisponivel) {
		this.saldoDisponivel = saldoDisponivel;
	}
	public double getLimiteCredito() {
		return limiteCredito;
	}
	public void setLimiteCredito(double limiteCredito) {
		this.limiteCredito = limiteCredito;
	}
	public LocalTime getHoraTransacao() {
		return horaTransacao;
	}
	public void setHoraTransacao(LocalTime horaTransacao) {
		this.horaTransacao = horaTransacao;
	}
	public LocalTime getHorarioLimiteIncio() {
		return HorarioLimiteIncio;
	}
	public void setHorarioLimiteIncio(LocalTime horarioLimiteIncio) {
		HorarioLimiteIncio = horarioLimiteIncio;
	}
	public LocalTime getHorarioLimiteFim() {
		return horarioLimiteFim;
	}
	public void setHorarioLimiteFim(LocalTime horarioLimiteFim) {
		this.horarioLimiteFim = horarioLimiteFim;
	}
	
	
	
}
