package TransacaoBancaria;

public class VerificadorLimiteCredito extends Autorizador{

	@Override
	public void autorizar(Transacao transacao) {
		if (transacao.getValor() <= transacao.getLimiteCredito()) {
			System.out.println("Limite de Credito aprovado.");
			if(proximo!=null)proximo.autorizar(transacao);
		}else {
			System.out.println("Erro: Limite de Credito ultrapassado.");
		}
	}
}
