package TransacaoBancaria;

import java.time.LocalTime;

public class Main {
	public static void main(String[] args) {
		Transacao transacao = new Transacao();
		
		transacao.setValor(100);
		transacao.setSaldoDisponivel(1000);
		transacao.setLimiteCredito(10000);
		//transacao.setHoraTransacao(LocalTime.now());
		
		LocalTime horaEspecifica = LocalTime.of(14, 30);
		transacao.setHoraTransacao(horaEspecifica);
		
		//Configurando transacao
		Autorizador verificaSaldo = new VerificadorSaldo();
		Autorizador verificaCredito = new VerificadorLimiteCredito();
		Autorizador verificaHorario = new VerificadorHorario();
		
		verificaSaldo.setProximo(verificaCredito);
		verificaCredito.setProximo(verificaHorario);
		
		verificaSaldo.autorizar(transacao);
	}
}
